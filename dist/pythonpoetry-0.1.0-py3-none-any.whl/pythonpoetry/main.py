from fastapi import FastAPI
from pythonpoetry.com.github.dheerajhegde.api import router
import uvicorn

"""def include_router(app):
    app.include_router(router.router)

def start_application():
    app = FastAPI()
    include_router(app)
    return app

if __name__ == "__main__":
    app = start_application()
    uvicorn.run(app)"""

app = FastAPI()
@app.get("/")
async def root():
    return {"message": "Hello World"}

@app.get("/name")
async def root():
    return {"message": "Hello World Dheeraj"}

if __name__ == "__main__":
    uvicorn.run(app)